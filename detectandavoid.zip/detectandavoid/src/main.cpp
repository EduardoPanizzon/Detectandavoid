#include <iostream>
#include <vector>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>

using namespace std;	
//---------------------------------------------------------------------------------
int main( int argc, char** argv )
{
    //checking system arguments
    if(argc != 2)
    {
        cout <<" Usage: <binary exec> ImagePath" << endl;
        return -1;
    }    
    
    //load input image by argument
    cv::Mat inputImage;
    cv::VideoCapture cap(argv[1]);

    // Check if camera opened successfully
    if(!cap.isOpened()){
        cout << "Error opening video stream or file" << endl;
        return -1;
    }

    cv::Point MalditoSeedPoint(10,10);
    while(1)
    {
        cv::Mat frame;
        cap >> frame;
        if (frame.empty())
        break;

        cv::namedWindow("Frame", 0);
        cv::imshow("Frame", frame );

        cv::Mat buffer = cv::Mat{frame.size() + cv::Size{2, 2}, CV_8U, cv::Scalar{0}};
        cv::Scalar thresArray = cv::Scalar::all(5);
        cv::floodFill(frame, buffer, MalditoSeedPoint, 255, NULL, thresArray, thresArray, 4 + (255 << 8) + cv::FLOODFILL_MASK_ONLY);
        cv::Mat m_background = buffer({{1, 1}, frame.size()}).clone();

        //detect the external contour of the selected shape
        //cv::Mat backgroundroi = m_background.clone();
        //std::vector<std::vector<cv::Point> > contour;
        //cv::findContours(backgroundroi, contour, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
        //cv::drawContours(backgroundroi, contour, -1, cv::Scalar(255), CV_FILLED);

        cv::namedWindow( "Display window", 0 );// Create a window for display.
        cv::imshow( "Display window", m_background );
        cv::waitKey(1);

        char c=(char) cv::waitKey(25);
        if(c==27)
            break;
    }

    return 0;
}
